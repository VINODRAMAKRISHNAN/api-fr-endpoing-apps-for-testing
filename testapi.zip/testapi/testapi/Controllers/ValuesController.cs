﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace testapi.Controllers
{
    public class Address
    {
        public string Street { get; set; }
        public string Zip { get; set; }

    }
        public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public bool Status { get; set; }

        public Address StAddress { get; set; }
    }
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        private List<Student> stds = CreateStudents();

        private static List<Student> CreateStudents()
        {
            Address ad1 = new Address { Street = "st1", Zip = "4000" };
            Address ad2 = new Address { Street = "st3", Zip = "5000" };
            Address ad3 = new Address { Street = "st4", Zip = "6000" };


            List<Student> stls = new List<Student>();
            stls.Add(new Student { Id = 1, Name = "aaa", Age = 11, Status = true, StAddress = ad1 });
            stls.Add(new Student { Id = 2, Name = "bb", Age = 12, Status = true, StAddress = ad2 });
            stls.Add(new Student { Id = 3, Name = "cc", Age = 13, Status = true, StAddress = ad3 });
            stls.Add(new Student { Id = 4, Name = "dd", Age = 14, Status = true, StAddress = ad1 });

            return stls;
        }


        // GET api/values
        [HttpGet]
        public List<Student> Get()
        {
            return stds;
        }

       
        // GET api/values/5
        [HttpGet("{id}")]
        public List<Student> Get(int id)
        {
            var x = stds.Where(t => t.Id == id);
            return x.ToList();
        }

        // POST api/values
        [HttpPost]
        public Student Post([FromBody]Student value)
        {
            List<Student> stls = new List<Student>();
            stls.Add(value);
            HttpContext.Response.StatusCode = 201;
            return value;
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
